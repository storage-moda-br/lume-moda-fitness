<?php
// send.php

header('Content-Type: application/json; charset=utf-8');

// =======================================
// Configuração inicial / tratamento de erros
// =======================================
$response = [
    'success' => false,
    'total'   => 0,
    'sent'    => 0,
    'failed'  => 0,
    'results' => [],
];

function sendJsonAndExit($response) {
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// =======================================
// Verifica método
// =======================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['error'] = 'Método inválido. Use POST.';
    sendJsonAndExit($response);
}

// =======================================
// Lê campos do POST
// =======================================
$smtpHost   = isset($_POST['smtp_host']) ? trim($_POST['smtp_host']) : '';
$smtpPort   = isset($_POST['smtp_port']) ? (int)$_POST['smtp_port'] : 0;
$smtpSecure = isset($_POST['smtp_secure']) ? trim($_POST['smtp_secure']) : 'tls';
$smtpUser   = isset($_POST['smtp_user']) ? trim($_POST['smtp_user']) : '';
$smtpPass   = isset($_POST['smtp_pass']) ? $_POST['smtp_pass'] : '';
$fromName   = isset($_POST['smtp_from_name']) ? trim($_POST['smtp_from_name']) : '';
$fromEmail  = isset($_POST['smtp_from_email']) ? trim($_POST['smtp_from_email']) : '';
$subjectTpl = isset($_POST['subject']) ? $_POST['subject'] : '';
$messageTpl = isset($_POST['message']) ? $_POST['message'] : '';
$delayMs    = isset($_POST['smtp_delay']) ? (int)$_POST['smtp_delay'] : 1000;

// Validações básicas
if (!$smtpHost || !$smtpPort || !$smtpUser || !$smtpPass || !$subjectTpl || !$messageTpl) {
    $response['error'] = 'Campos obrigatórios ausentes (host, porta, usuário, senha, assunto ou mensagem).';
    sendJsonAndExit($response);
}

if (!$fromEmail) {
    // por padrão, usa o próprio usuário como remetente
    $fromEmail = $smtpUser;
}

// Delay mínimo 0, máximo algo razoável para evitar exagero (ex: 30s)
if ($delayMs < 0) {
    $delayMs = 0;
}
if ($delayMs > 30000) {
    $delayMs = 30000;
}

// =======================================
// Lê o arquivo clientes.txt
// =======================================
$clientesFile = __DIR__ . '/clientes.txt';
if (!file_exists($clientesFile)) {
    $response['error'] = 'Arquivo clientes.txt não encontrado.';
    sendJsonAndExit($response);
}

$lines = file($clientesFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$clientes = [];

foreach ($lines as $line) {
    $line = trim($line);
    if ($line === '') continue;
    if (strpos($line, '#') === 0) continue; // permite comentários com #

    // Formato: nome;cpf;email;
    $parts = explode(';', $line);
    if (count($parts) < 3) {
        // linha inválida - ignora
        continue;
    }

    $nome  = trim($parts[0]);
    $cpf   = trim($parts[1]);
    $email = trim($parts[2]);

    if ($email === '') continue;

    $clientes[] = [
        'nome'  => $nome,
        'cpf'   => $cpf,
        'email' => $email,
    ];
}

if (empty($clientes)) {
    $response['error'] = 'Nenhum cliente válido encontrado em clientes.txt.';
    sendJsonAndExit($response);
}

// =======================================
// Funções auxiliares
// =======================================
function gerarNumeroSeisDigitos() {
    // 000000 a 999999
    return str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

function gerarProtocoloAlfanumerico() {
    // Começa com 'A' + 5 caracteres [A-Z0-9]
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $proto = 'A';
    for ($i = 0; $i < 5; $i++) {
        $proto .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $proto;
}

function aplicarVariaveis($texto, $nome, $cpf, $numero, $protocolo) {
    $map = [
        '#NOME#'      => $nome,
        '#CPF#'       => $cpf,
        '#NUMERO#'    => $numero,
        '#PROTOCOLO#' => $protocolo,
    ];
    return strtr($texto, $map);
}

// =======================================
// Configura PHPMailer
// =======================================
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/vendor/autoload.php';

// Apenas confiável se estiver em ambiente controlado (como você descreveu)
$mail = new PHPMailer(true);
$mail->CharSet   = 'UTF-8';
$mail->Encoding  = 'base64';

$mail->isSMTP();
$mail->Host       = $smtpHost;
$mail->Port       = $smtpPort;
$mail->SMTPAuth   = true;
$mail->Username   = $smtpUser;
$mail->Password   = $smtpPass;
$mail->SMTPDebug  = 0;

// Criptografia
if ($smtpSecure === 'ssl') {
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
} elseif ($smtpSecure === 'tls') {
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
} else {
    // nenhuma
    $mail->SMTPSecure = false;
    $mail->SMTPAutoTLS = false;
}

// Remetente
$mail->setFrom($fromEmail, $fromName ?: $fromEmail);

// =======================================
// Loop de envio
// =======================================
$total  = count($clientes);
$sent   = 0;
$failed = 0;
$results = [];

$index = 1;

foreach ($clientes as $cli) {
    $nome  = $cli['nome'];
    $cpf   = $cli['cpf'];
    $email = $cli['email'];

    $numero    = gerarNumeroSeisDigitos();
    $protocolo = gerarProtocoloAlfanumerico();

    $subject = aplicarVariaveis($subjectTpl, $nome, $cpf, $numero, $protocolo);
    $body    = aplicarVariaveis($messageTpl, $nome, $cpf, $numero, $protocolo);

    try {
        // Limpa destinatários de loops anteriores
        $mail->clearAddresses();
        $mail->clearAttachments();

        $mail->addAddress($email, $nome ?: $email);
        $mail->Subject = $subject;
        $mail->isHTML(true);
        $mail->Body    = $body;
        $mail->AltBody = strip_tags($body);

        $mail->send();

        $sent++;
        $results[] = [
            'index'   => $index,
            'name'    => $nome,
            'cpf'     => $cpf,
            'email'   => $email,
            'status'  => 'success',
            'message' => 'ENVIADO COM SUCESSO',
            'numero'  => $numero,
            'protocolo' => $protocolo,
        ];
    } catch (Exception $e) {
        $failed++;
        $results[] = [
            'index'   => $index,
            'name'    => $nome,
            'cpf'     => $cpf,
            'email'   => $email,
            'status'  => 'error',
            'message' => $mail->ErrorInfo ?: $e->getMessage(),
            'numero'  => $numero,
            'protocolo' => $protocolo,
        ];
    }

    $index++;

    // Delay entre envios (se > 0)
    if ($delayMs > 0 && $index <= $total) {
        usleep($delayMs * 1000); // ms -> microsegundos
    }
}

// =======================================
// Retorna JSON final
// =======================================
$response['success'] = true;
$response['total']   = $total;
$response['sent']    = $sent;
$response['failed']  = $failed;
$response['results'] = $results;

sendJsonAndExit($response);
