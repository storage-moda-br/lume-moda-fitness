<?php
// send.php

header('Content-Type: application/json; charset=utf-8');

// =======================================
// Função para retornar JSON
// =======================================
function sendJsonAndExit($response) {
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

$response = [
    'success' => false,
    'total'   => 0,
    'sent'    => 0,
    'failed'  => 0,
    'results' => [],
];

// =======================================
// Verifica método
// =======================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['error'] = 'Método inválido. Use POST.';
    sendJsonAndExit($response);
}

// =======================================
// Receber dados do POST
// =======================================
$smtpHost   = trim($_POST['smtp_host'] ?? '');
$smtpPort   = (int)($_POST['smtp_port'] ?? 0);
$smtpUser   = trim($_POST['smtp_user'] ?? '');
$smtpPass   = $_POST['smtp_pass'] ?? '';
$fromName   = trim($_POST['smtp_from_name'] ?? '');
$fromEmail  = trim($_POST['smtp_from_email'] ?? '');
$subjectTpl = $_POST['subject'] ?? '';
$messageTpl = $_POST['message'] ?? '';
$delayMs    = (int)($_POST['smtp_delay'] ?? 1000);

// ⚠️ IMPORTANTE: seu formulário envia "secure", NÃO "smtp_secure"
$smtpSecure = trim($_POST['secure'] ?? 'none');

// Preenchimento do campo remetente
if (!$fromEmail) {
    $fromEmail = $smtpUser;
}

// Validação básica
if (!$smtpHost || !$smtpPort || !$smtpUser || !$smtpPass || !$subjectTpl || !$messageTpl) {
    $response['error'] = 'Campos obrigatórios ausentes.';
    sendJsonAndExit($response);
}

// Delay entre 0 e 30000 ms
if ($delayMs < 0) $delayMs = 0;
if ($delayMs > 30000) $delayMs = 30000;

// =======================================
// Ler clientes.txt
// =======================================
$clientesFile = __DIR__ . '/clientes.txt';
if (!file_exists($clientesFile)) {
    $response['error'] = 'Arquivo clientes.txt não encontrado.';
    sendJsonAndExit($response);
}

$lines = file($clientesFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$clientes = [];
foreach ($lines as $line) {
    $line = trim($line);
    if ($line === '' || strpos($line, '#') === 0) continue;

    $parts = explode(';', $line);
    if (count($parts) < 3) continue;

    $nome  = trim($parts[0]);
    $cpf   = trim($parts[1]);
    $email = trim($parts[2]);

    if ($email === '') continue;

    $clientes[] = [
        'nome'  => $nome,
        'cpf'   => $cpf,
        'email' => $email,
    ];
}

if (empty($clientes)) {
    $response['error'] = 'Nenhum cliente válido encontrado.';
    sendJsonAndExit($response);
}

// =======================================
// Funções auxiliares
// =======================================
function gerarNumeroSeisDigitos() {
    return str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

function gerarProtocoloAlfanumerico() {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $p = 'A';
    for ($i = 0; $i < 5; $i++) {
        $p .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $p;
}

function aplicarVariaveis($texto, $nome, $cpf, $numero, $protocolo) {
    return strtr($texto, [
        '#NOME#'      => $nome,
        '#CPF#'       => $cpf,
        '#NUMERO#'    => $numero,
        '#PROTOCOLO#' => $protocolo,
    ]);
}

// =======================================
// PHPMailer
// =======================================
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/vendor/autoload.php';

$mail = new PHPMailer(true);
$mail->CharSet  = 'UTF-8';
$mail->Encoding = 'base64';

$mail->isSMTP();
$mail->Host       = $smtpHost;
$mail->Port       = $smtpPort;
$mail->SMTPAuth   = true;
$mail->Username   = $smtpUser;
$mail->Password   = $smtpPass;

// =======================================
// ⚠️ CONFIGURAÇÃO DE SEGURANÇA REALMENTE FUNCIONAL
// =======================================

// O Mailtrap SANDBOX **NÃO** suporta STARTTLS implícito
// Se você deixar como padrão, PHPMailer ativa STARTTLS sozinho → ERRO após o 1º email
$mail->SMTPAutoTLS = false;

// Configurações de criptografia
if ($smtpSecure === 'ssl') {
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
} elseif ($smtpSecure === 'tls') {
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
} else {
    // Nenhuma criptografia (modo correto para Mailtrap Sandbox)
    $mail->SMTPSecure = '';
}

// Impede reuso da conexão → essencial para Mailtrap Sandbox
$mail->SMTPKeepAlive = false;

// Remetente
$mail->setFrom($fromEmail, $fromName ?: $fromEmail);

// =======================================
// Loop de envio
// =======================================
$total    = count($clientes);
$sent     = 0;
$failed   = 0;
$results  = [];
$index    = 1;

foreach ($clientes as $cli) {
    $nome  = $cli['nome'];
    $cpf   = $cli['cpf'];
    $email = $cli['email'];

    $numero    = gerarNumeroSeisDigitos();
    $protocolo = gerarProtocoloAlfanumerico();

    $subject = aplicarVariaveis($subjectTpl, $nome, $cpf, $numero, $protocolo);
    $body    = aplicarVariaveis($messageTpl, $nome, $cpf, $numero, $protocolo);

    try {
        $mail->clearAddresses();
        $mail->clearAttachments();

        $mail->addAddress($email, $nome ?: $email);
        $mail->Subject = $subject;
        $mail->isHTML(true);
        $mail->Body    = $body;
        $mail->AltBody = strip_tags($body);

        $mail->send();

        $sent++;
        $results[] = [
            'index'   => $index,
            'email'   => $email,
            'name'    => $nome,
            'cpf'     => $cpf,
            'status'  => 'success',
            'message' => 'ENVIADO COM SUCESSO',
            'numero'  => $numero,
            'protocolo' => $protocolo,
        ];

    } catch (Exception $e) {
        $failed++;
        $results[] = [
            'index'   => $index,
            'email'   => $email,
            'name'    => $nome,
            'cpf'     => $cpf,
            'status'  => 'error',
            'message' => $mail->ErrorInfo ?: $e->getMessage(),
            'numero'  => $numero,
            'protocolo' => $protocolo,
        ];
    }

    $index++;

    // Delay entre envios
    if ($delayMs > 0 && $index <= $total) {
        usleep($delayMs * 1000);
    }
}

// =======================================
// Retorna JSON
// =======================================
$response['success'] = true;
$response['total']   = $total;
$response['sent']    = $sent;
$response['failed']  = $failed;
$response['results'] = $results;
sendJsonAndExit($response);
